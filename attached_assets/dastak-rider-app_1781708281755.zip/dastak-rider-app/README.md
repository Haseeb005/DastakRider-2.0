# Dastak Rider App

Standalone delivery partner app for Dastak — connects to the same MongoDB database as the main Dastak customer app.

## Setup in a new Replit project

### 1. Create the project
- Go to replit.com → Create Repl → **Node.js**
- Upload or paste all files from this folder

### 2. Add your secret
In the Replit Secrets tab, add:
```
MONGODB_URI = mongodb+srv://...your connection string...
```
Use the **exact same** MongoDB URI as your main Dastak app — the rider app reads orders from the same database.

### 3. Configure the workflow
In the Replit Workflows tab, set the run command to:
```
npm run dev
```

### 4. Install dependencies
Replit will auto-install from package.json, or run:
```
npm install
```

### 5. Open the app
Visit the app URL — you'll see the Dastak Rider login screen.

---

## Features

| Feature | Description |
|---------|-------------|
| Login / Register | Phone + password auth for riders |
| Available Orders | See all unassigned orders, auto-refreshes every 10s |
| Accept Orders | One tap to claim an order |
| Active Delivery | Update status: Confirmed → At Restaurant → On the Way → Delivered |
| Earnings | Today / This Week / All-time earnings summary |
| History | List of completed deliveries |
| Profile | Online/Offline toggle, account details, logout |

## How it works with the main app

```
Customer places order (Dastak App)
        ↓
Order saved to MongoDB with status "placed"
        ↓
Rider App polls every 10s → sees new order
        ↓
Rider accepts → order gets riderName, riderPhone, status "confirmed"
        ↓
Customer's order page shows rider details instantly
        ↓
Rider updates status → Delivered
        ↓
Rider's earnings automatically updated
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `MONGODB_URI` | ✅ Yes | MongoDB connection string (same as main Dastak app) |
| `SESSION_SECRET` | Recommended | Secret for session encryption (use a long random string) |
| `PORT` | No | Server port (default: 3000) |

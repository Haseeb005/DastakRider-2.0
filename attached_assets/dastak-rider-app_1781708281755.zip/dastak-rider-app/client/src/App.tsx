import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "./components/ui/toaster";
import RiderApp from "./pages/RiderApp";

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RiderApp />
      <Toaster />
    </QueryClientProvider>
  );
}

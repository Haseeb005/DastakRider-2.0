import { useState, useCallback } from "react";

export interface Toast {
  id: string;
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
}

type ToastInput = Omit<Toast, "id">;

let listeners: Array<(toasts: Toast[]) => void> = [];
let toasts: Toast[] = [];

function notify() {
  listeners.forEach((l) => l([...toasts]));
}

export function toast(input: ToastInput) {
  const id = Math.random().toString(36).slice(2);
  toasts = [...toasts, { ...input, id }];
  notify();
  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    notify();
  }, 4000);
}

export function useToast() {
  const [, rerender] = useState(0);

  const subscribe = useCallback(() => {
    const listener = () => rerender((n) => n + 1);
    listeners.push(listener);
    return () => { listeners = listeners.filter((l) => l !== listener); };
  }, []);

  useState(subscribe);

  return { toast, toasts };
}

export function getToasts() {
  return toasts;
}

import { useToast } from "../../hooks/use-toast";
import { clsx } from "clsx";

export function Toaster() {
  const { toasts } = useToast();

  return (
    <div className="fixed bottom-4 right-4 z-[9999] flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={clsx(
            "pointer-events-auto rounded-xl shadow-lg p-4 text-sm transition-all animate-in slide-in-from-bottom-2",
            t.variant === "destructive"
              ? "bg-red-600 text-white"
              : "bg-gray-900 text-white"
          )}
        >
          {t.title && <p className="font-semibold">{t.title}</p>}
          {t.description && <p className="opacity-90 mt-0.5">{t.description}</p>}
        </div>
      ))}
    </div>
  );
}

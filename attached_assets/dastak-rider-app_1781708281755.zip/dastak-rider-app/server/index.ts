import express from "express";
import session from "express-session";
import MemoryStore from "memorystore";
import { MongoClient, type Db } from "mongodb";
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── MongoDB ───────────────────────────────────────────────────────────────────
let db: Db;

async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI environment variable is required. Check your .env file.");
  const client = new MongoClient(uri);
  await client.connect();
  db = client.db();
  console.log("[db] Connected to MongoDB");
}

const ridersCol = () => db.collection("riders");
const ordersCol = () => db.collection("orders");

// ── Auth helpers ──────────────────────────────────────────────────────────────
function getRiderId(req: any): string {
  return (req.session as any)?.riderId || "";
}

function requireRiderId(req: any, res: any): string | null {
  const id = getRiderId(req);
  if (!id) { res.status(401).json({ message: "Rider not logged in" }); return null; }
  return id;
}

// ── Express app ───────────────────────────────────────────────────────────────
const app = express();
app.use(express.json());

const Store = MemoryStore(session);
app.use(
  session({
    secret: process.env.SESSION_SECRET || "dastak-rider-secret-change-in-prod",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: "lax" },
    store: new Store({ checkPeriod: 86_400_000 }),
  })
);

// ── Rider API ─────────────────────────────────────────────────────────────────

app.post("/api/rider/register", async (req: any, res) => {
  try {
    const { name, phone, password, city, vehicleType } = req.body;
    if (!name || !phone || !password || !city || !vehicleType)
      return res.status(400).json({ message: "All fields are required" });
    const col = ridersCol();
    const normPhone = phone.replace(/[\s\-()]/g, "");
    if (await col.findOne({ phone: normPhone }))
      return res.status(409).json({ message: "Phone number already registered" });
    const passwordHash = await bcrypt.hash(password, 12);
    const rider = {
      id: randomUUID(), name: name.trim(), phone: normPhone, passwordHash,
      city, vehicleType, isOnline: false, isAvailable: true,
      totalEarnings: 0, totalDeliveries: 0, rating: 0, ratingCount: 0,
      createdAt: new Date(),
    };
    await col.insertOne(rider);
    (req.session as any).riderId = rider.id;
    await new Promise<void>((ok, fail) => req.session.save((e: any) => e ? fail(e) : ok()));
    const { passwordHash: _, ...safe } = rider;
    res.status(201).json(safe);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.post("/api/rider/login", async (req: any, res) => {
  try {
    const { phone, password } = req.body;
    if (!phone || !password)
      return res.status(400).json({ message: "Phone and password are required" });
    const col = ridersCol();
    const normPhone = phone.replace(/[\s\-()]/g, "");
    const rider = await col.findOne({ phone: normPhone });
    if (!rider || !(await bcrypt.compare(password, rider.passwordHash)))
      return res.status(401).json({ message: "Invalid phone number or password" });
    (req.session as any).riderId = rider.id;
    await new Promise<void>((ok, fail) => req.session.save((e: any) => e ? fail(e) : ok()));
    const { passwordHash: _, ...safe } = rider;
    res.json(safe);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.post("/api/rider/logout", (req: any, res) => {
  (req.session as any).riderId = undefined;
  req.session.save(() => res.json({ ok: true }));
});

app.get("/api/rider/me", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const rider = await ridersCol().findOne({ id: riderId });
    if (!rider) {
      (req.session as any).riderId = undefined;
      return res.status(401).json({ message: "Rider not found" });
    }
    const { passwordHash: _, ...safe } = rider;
    res.json(safe);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.put("/api/rider/availability", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const { isOnline } = req.body;
    await ridersCol().updateOne({ id: riderId }, { $set: { isOnline: !!isOnline, updatedAt: new Date() } });
    res.json({ ok: true, isOnline: !!isOnline });
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.get("/api/rider/orders/available", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const docs = await ordersCol().find({
      status: { $in: ["placed"] },
      $or: [{ riderId: { $exists: false } }, { riderId: null }, { riderId: "" }],
    }).sort({ createdAt: -1 }).limit(100).toArray();
    res.json(docs);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.get("/api/rider/orders/active", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const docs = await ordersCol().find({
      riderId,
      status: { $in: ["confirmed", "preparing", "out_for_delivery"] },
    }).sort({ createdAt: -1 }).toArray();
    res.json(docs);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.get("/api/rider/orders/history", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const docs = await ordersCol()
      .find({ riderId, status: "delivered" })
      .sort({ updatedAt: -1 }).limit(100).toArray();
    res.json(docs);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.post("/api/rider/orders/:id/accept", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const rider = await ridersCol().findOne({ id: riderId });
    if (!rider) return res.status(404).json({ message: "Rider not found" });
    const activeCount = await ordersCol().countDocuments({
      riderId, status: { $in: ["confirmed", "preparing", "out_for_delivery"] },
    });
    if (activeCount > 0)
      return res.status(400).json({ message: "Complete your current delivery first." });
    const updated = await ordersCol().findOneAndUpdate(
      {
        id: req.params.id, status: "placed",
        $or: [{ riderId: { $exists: false } }, { riderId: null }, { riderId: "" }],
      },
      {
        $set: {
          riderId, riderName: rider.name, riderPhone: rider.phone,
          riderVehicle: rider.vehicleType, riderRating: rider.rating,
          riderRatingCount: rider.ratingCount, status: "confirmed", updatedAt: new Date(),
        },
      },
      { returnDocument: "after" }
    );
    if (!updated) return res.status(409).json({ message: "Order already taken or unavailable." });
    res.json(updated);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.put("/api/rider/orders/:id/status", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const { status } = req.body;
    if (!["preparing", "out_for_delivery", "delivered"].includes(status))
      return res.status(400).json({ message: "Invalid status" });
    const updated = await ordersCol().findOneAndUpdate(
      { id: req.params.id, riderId },
      { $set: { status, updatedAt: new Date() } },
      { returnDocument: "after" }
    );
    if (!updated) return res.status(404).json({ message: "Order not found or not assigned to you." });
    if (status === "delivered") {
      const deliveryFee = parseFloat(updated.deliveryFee) || 50;
      await ridersCol().updateOne(
        { id: riderId },
        { $inc: { totalEarnings: deliveryFee, totalDeliveries: 1 }, $set: { isAvailable: true, updatedAt: new Date() } }
      );
    }
    res.json(updated);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

app.get("/api/rider/earnings", async (req: any, res) => {
  try {
    const riderId = requireRiderId(req, res);
    if (!riderId) return;
    const rider = await ridersCol().findOne({ id: riderId });
    if (!rider) return res.status(404).json({ message: "Rider not found" });
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const [todayOrders, weekOrders] = await Promise.all([
      ordersCol().find({ riderId, status: "delivered", updatedAt: { $gte: today } }).toArray(),
      ordersCol().find({ riderId, status: "delivered", updatedAt: { $gte: weekStart } }).toArray(),
    ]);
    const sum = (arr: any[]) => arr.reduce((s, o) => s + (parseFloat(o.deliveryFee) || 50), 0);
    res.json({
      totalEarnings: rider.totalEarnings || 0,
      totalDeliveries: rider.totalDeliveries || 0,
      todayEarnings: sum(todayOrders),
      todayDeliveries: todayOrders.length,
      weekEarnings: sum(weekOrders),
      weekDeliveries: weekOrders.length,
      rating: rider.rating || 0,
      ratingCount: rider.ratingCount || 0,
    });
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

// ── Frontend serving ──────────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || "3000");

async function start() {
  await connectDB();

  if (process.env.NODE_ENV === "production") {
    const distPath = path.resolve(__dirname, "../dist/public");
    app.use(express.static(distPath));
    app.get("*", (_, res) => res.sendFile(path.join(distPath, "index.html")));
  } else {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa",
      root: path.resolve(__dirname, "../client"),
      resolve: {
        alias: { "@": path.resolve(__dirname, "../client/src") },
      },
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Dastak Rider App → http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Failed to start:", err);
  process.exit(1);
});
